$db = mysqli_connect("localhost","root","","facemask"); //keep your db name
$sql = "SELECT * FROM 2ndnotification WHERE id = $id";
$sth = $db->query($sql);
$result=mysqli_fetch_array($);
echo '<img src="data:rest/jpeg;base64,'.base64_encode($rest->load()) .'" />';
