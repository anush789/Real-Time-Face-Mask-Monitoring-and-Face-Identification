<?php

$db = mysqli_connect("localhost","root","","facemask");  // database connection

if(!$db)
{
    die("Connection failed: " . mysqli_connect_error());
}

?>